import { RoleType } from '../shared/constants/roles.js';
import { Types } from 'mongoose';

declare global {
  namespace Express {
    interface Request {
      user: {
        id: string;
        userId: Types.ObjectId;
        email: string;
        role: RoleType;
        branchId?: string;
      };
      requestId: string;
    }
  }
}

export {};
