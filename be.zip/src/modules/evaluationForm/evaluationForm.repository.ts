import { Types } from 'mongoose';
import { Class } from '../../models/class.model.js';
import { ClassSession } from '../../models/classSession.model.js';
import { Enrollment } from '../../models/enrollment.model.js';
import { EvaluationForm, IEvaluationForm } from '../../models/evaluationForm.model.js';
import { User } from '../../models/user.model.js';

export class EvaluationFormRepository {
  async findClassById(classId: string) {
    return await Class.findOne({ _id: classId, deletedAt: null }).lean();
  }

  async findSessionById(sessionId: string) {
    return await ClassSession.findOne({ _id: sessionId, deletedAt: null }).lean();
  }

  async findStudentById(studentId: string) {
    return await User.findOne({ _id: studentId, deletedAt: null }).lean();
  }

  async findActiveEnrollment(studentId: string, classId: string) {
    return await Enrollment.findOne({
      studentId: new Types.ObjectId(studentId),
      classId: new Types.ObjectId(classId),
      leftAt: null,
    }).lean();
  }

  async create(data: Partial<IEvaluationForm>) {
    return await EvaluationForm.create(data);
  }

  async findById(id: string) {
    return await EvaluationForm.findById(id);
  }

  async findMany(filter: MongoFilter<IEvaluationForm>) {
    return await EvaluationForm.find(filter)
      .populate('studentId', 'fullName userCode email phone')
      .populate('classId', 'name classCode subject classType teacherSnapshot')
      .populate('sessionId', 'sessionDate startTime endTime roomCode status')
      .populate('teacherId', 'fullName email')
      .populate('createdBy', 'fullName email role')
      .sort({ createdAt: -1 })
      .lean();
  }
}
